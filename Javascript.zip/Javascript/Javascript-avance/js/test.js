var tabPrenoms= ['Rositta', 'Bob', 'Gaston', 'Roberto'];
for(var i=0;i<tabPrenoms.lenght;i++) {
  alert(tabPrenoms[i])
}
