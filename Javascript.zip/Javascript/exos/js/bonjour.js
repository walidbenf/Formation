var nom=prompt("Entrer votre nom");
var prenom=prompt("Entrer votre prenom");
if(nom && prenom) {
  alert(nom + " " + prenom);
}
