var rect = document.querySelector(".rectangle");

function rectangle() {
  rect.classList.toggle("hide");
}
function hover(){
  rect.classList.add("good");

}
