var nb = Number(prompt("Entrer un nombre de tours"));
var nb2=1;
while(nb2<=nb){
document.write("C'est le tour de manège n°"+ nb2+ "<br>");
nb2++;
}
