/*var nb0 = Number(prompt("Entrer un chiffre"));
var nb1 = 1;
var nb2 = 2;
var nb3 = 3;
var nb4 = 4;
var nb5 = 5;
var nb6 = 6;
var nb7 = 7;
var nb8 = 8;
var nb9 = 9;
var nb10 = 10;
var nb11 = 11;
var nb12 = 2;*/
var j0 = Number(prompt("Entrer un mois"));
switch (j0) {
  case 1:
    document.write("31");
    break;
  case 2:
    document.write("28");
    break;
  case 3:
    document.write("31");
    break;
  case 4:
    document.write("30");
    break;
  case 5:
    document.write("31");
    break;
  case 6:
    document.write("30");
    break;
  case 7:
    document.write("31");
    break;
  case 8:
    document.write("31");
    break;
  case 9:
    document.write("30");
    break;
  case 10:
    document.write("31");
    break;
  case 11:
    document.write("30");
    break;
  case 12:
    document.write("31");
    break;
}

var mois=prompt("Saisir un mois");

if(mois == 2) {
  document.write("Ce mois contient 28 jours");
}
else if((mois === 1) ||)
