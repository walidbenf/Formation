var nb1 = Number(prompt("Entrez nb1 :"));
var nb2 = Number(prompt("Entrez nb2 :"));
var nb3 = Number(prompt("Entrez nb3 :"));
if (nb1 > nb2) {
  nb1 = nb3 * 2;
} else {
  nb1++;
  if (nb2 > nb3) {
    nb1 = nb1 + nb3 * 3;
  } else {
    nb1 = 0;
    nb3 = nb3 * 2 + nb2;
  }
}
document.write('le chiffre final de nb1 est' + nb1);
document.write('<br>'+ "Le chiffre final de nb2 est" + nb2);
document.write('<br>'+ "Le chiffre final de nb3 est" + nb3);
