i=1;
for (var i = 1; i <= 100; i++) {
  if(i % 3 = 0;){
    i="Fizz";
    document.write("Tour de boucle n°" + i + "<br>");
  }
  document.write("Tour de boucle n°" + i + "<br>");
}
