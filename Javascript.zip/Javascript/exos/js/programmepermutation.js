var nombre1 = 5;
var nombre2 = 3;
console.log(nombre1);
console.log(nombre2);
