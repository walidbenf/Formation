str = "";
for (var i = 0; i < 7; i++) {
  str += "-";
  document.write( "<br>"+str + "<br>");
}
