var temp = Number(prompt("Entrer la température"));
var far=temp * 1.8 + 32;
if (temp) {
alert(far);
}
