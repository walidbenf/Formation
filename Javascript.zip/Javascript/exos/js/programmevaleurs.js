var b= 8;
b+= 2;
var a =2;

var c= a + b* b;

var d= a * b + b;

var e = a * (b+b);

var f= a * b / a;

var g= b / a * a;

document.write("</br>" + c + "<br>" + d + "<br>" + e + "<br>" + f + "<br>" + g);
