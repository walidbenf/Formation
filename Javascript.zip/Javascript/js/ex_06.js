//var myImg = new Image();
var conf=confirm("Voulez-vous changer d'image");
function test (){
if (conf) {
  //myImg.src = "http://www.mon-site.com/une-image.png";
document.getElementById("img").style.backgroundColor = "lightblue";
}
}
