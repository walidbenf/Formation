// Variable type String
var tomtom = "225";
// Variable type Boolean
var toto = true;
// Variable type Number
var yancy = 1.09;

calcul = tomtom + ' ' + toto + ' ' + yancy;

console.log(calcul);
document.write(calcul + "<br>");
// document.write(typeof(calcul));

var jour = 'Lundi', mois = 01, annee = 'Janvier';
document.write(jour + ' ' + mois + ' ' + annee + "<br>");
