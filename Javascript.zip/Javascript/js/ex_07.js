var nb= Number(prompt())
