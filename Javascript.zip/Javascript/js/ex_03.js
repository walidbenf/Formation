var nb1 = Number(prompt("Entrer un nombre"));
var resultat = nb1 % 5;
if (typeof nb1 == 'number') {
  alert("Si l'on divise " + nb1 + " par  5 le reste est de " + resultat);
}
